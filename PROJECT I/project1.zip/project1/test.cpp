//#include <iostream>
//#include <cstdlib> // For atoi and atof
//
//int main() {
//    char charArray[] = "1234.56";
//    
//    int intValue = atoi(charArray);      // Convert char array to int
//    double doubleValue = atof(charArray); // Convert char array to double
//    
//    std::cout << "Integer value: " << intValue + 1<< std::endl;
//    std::cout << "Double value: " << doubleValue << std::endl;
//    
//    return 0;
//}

